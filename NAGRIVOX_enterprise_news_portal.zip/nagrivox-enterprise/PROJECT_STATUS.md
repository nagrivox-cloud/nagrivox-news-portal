# NAGRIVOX project status

This is a runnable full-stack starter, not yet a deployed public website.

Implemented: public homepage, bilingual article fields, public article detail pages, team login, newsroom dashboard, article creation/editing, role-aware review/publish controls, Supabase schema and RLS.

Not yet configured: Supabase project credentials, first owner account, team invitations/roles, custom domain, production deployment, email/SMTP, image storage uploads, monitoring/backups, legal policy review.
