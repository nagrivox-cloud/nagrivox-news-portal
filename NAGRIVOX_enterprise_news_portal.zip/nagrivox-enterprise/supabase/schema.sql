-- NAGRIVOX newsroom schema
create extension if not exists pgcrypto;

create type public.member_role as enum ('owner', 'editor', 'reporter');
create type public.article_status as enum ('draft', 'in_review', 'published', 'archived');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Team member',
  role public.member_role not null default 'reporter',
  created_at timestamptz not null default now()
);

create table public.articles (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  category text not null,
  status public.article_status not null default 'draft',
  title_en text not null,
  title_hi text not null default '',
  excerpt_en text not null default '',
  excerpt_hi text not null default '',
  body_en text not null default '',
  body_hi text not null default '',
  cover_image text not null default '',
  author_id uuid not null references public.profiles(id),
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index articles_public_idx on public.articles(status, published_at desc);
create index articles_author_idx on public.articles(author_id, updated_at desc);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', 'Team member'), 'reporter')
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.current_role()
returns public.member_role language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid()
$$;

alter table public.profiles enable row level security;
alter table public.articles enable row level security;

create policy "members can view profiles"
on public.profiles for select to authenticated
using (id = auth.uid() or public.current_role() in ('owner','editor'));

create policy "owner manages profiles"
on public.profiles for update to authenticated
using (public.current_role() = 'owner')
with check (public.current_role() = 'owner');

create policy "public reads published articles"
on public.articles for select to anon, authenticated
using (status = 'published');

create policy "reporters read own and editors read all"
on public.articles for select to authenticated
using (
  author_id = auth.uid()
  or public.current_role() in ('owner','editor')
);

create policy "reporters create own articles"
on public.articles for insert to authenticated
with check (
  author_id = auth.uid()
  and (
    public.current_role() in ('owner','editor')
    or (public.current_role() = 'reporter' and status in ('draft','in_review'))
  )
);

create policy "reporters edit own drafts; editors manage all"
on public.articles for update to authenticated
using (
  (author_id = auth.uid() and status in ('draft','in_review'))
  or public.current_role() in ('owner','editor')
)
with check (
  (author_id = auth.uid() and status in ('draft','in_review'))
  or public.current_role() in ('owner','editor')
);

create policy "editors delete articles"
on public.articles for delete to authenticated
using (public.current_role() in ('owner','editor'));

-- Note: team member role changes should be performed by the owner using trusted
-- Supabase dashboard/admin tooling. Never expose the service-role key to clients.
