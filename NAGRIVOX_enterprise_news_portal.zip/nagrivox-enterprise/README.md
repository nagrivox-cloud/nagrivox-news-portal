# NAGRIVOX — Enterprise News Portal Starter

A bilingual (English/Hindi) editorial portal with a team publishing workflow, Supabase authentication, role-based access, article drafts/review/publishing, and a public news homepage.

## Stack
- Next.js App Router + TypeScript
- Supabase Auth + Postgres + Row Level Security
- Responsive editorial UI
- English/Hindi content fields

## 1. Create the backend
1. Create a Supabase project.
2. Open **SQL Editor** and run `supabase/schema.sql`.
3. In Supabase Authentication settings, keep public sign-ups disabled for a controlled newsroom.
4. Create the first user in Authentication > Users.
5. Copy that user's UUID. In SQL Editor, run:
   ```sql
   update public.profiles set role = 'owner' where id = 'YOUR_AUTH_USER_UUID';
   ```
   The profile row is created automatically when a user signs up. If it is not, insert it manually:
   ```sql
   insert into public.profiles (id, display_name, role)
   values ('YOUR_AUTH_USER_UUID', 'NAGRIVOX Owner', 'owner')
   on conflict (id) do update set role = 'owner';
   ```
6. Add the Supabase project URL and anon/publishable key to `.env.local` using `.env.example`.

## 2. Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000

## 3. Team roles
- `owner`: full access and team administration (manage team members in Supabase initially)
- `editor`: can review, publish, edit and archive newsroom articles
- `reporter`: can create and edit own drafts, submit for review

For the first release, invite staff through Supabase Authentication > Users. Set their role in `public.profiles`. Do not expose a public sign-up form.

## 4. Deploy
- Push this folder to a private GitHub repository.
- Import it into Vercel.
- Add the three environment variables from `.env.example` in Vercel.
- Deploy, then set `NEXT_PUBLIC_SITE_URL` to the deployed HTTPS domain.
- Add the domain in Vercel and configure DNS at the domain registrar when ready.

## Important launch checklist
- Replace the demo brand/contact details as required.
- Configure SMTP/custom email in Supabase Auth.
- Set up backups and a named editorial owner.
- Add a privacy policy, terms, corrections policy and editorial standards reviewed for your jurisdiction.
- Use only images you own, license, or have permission to publish.
- Verify every report and cite sources before publishing.
- Add CAPTCHA/rate limiting and monitoring before opening any public submissions.
- This starter does not include ad networks, analytics, comments, or automated news scraping.

## Security notes
- All article access is protected by Postgres RLS.
- Public visitors can only read published articles.
- Reporters can manage their own drafts; editors/owners can manage newsroom content.
- Never put a Supabase service-role key in browser-visible environment variables.
