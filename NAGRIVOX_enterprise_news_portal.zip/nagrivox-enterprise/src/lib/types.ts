export type Article = {
  id: string; slug: string; category: string; status: "draft"|"in_review"|"published"|"archived";
  title_en: string; title_hi: string; excerpt_en: string; excerpt_hi: string;
  body_en: string; body_hi: string; cover_image: string; author_id: string;
  published_at: string|null; created_at: string; updated_at: string;
};
