export default function Footer() {
  return <footer className="footer"><div className="shell" style={{display:"flex",justifyContent:"space-between",gap:20,flexWrap:"wrap"}}>
    <div><div className="logo" style={{color:"#fff"}}>NAGRI<span>VOX</span></div><small>Ideas That Matter. Voices That Count.</small></div>
    <div><a href="/about">About</a> · <a href="/editorial-policy">Editorial Policy</a> · <a href="/privacy">Privacy</a><br/><small>© {new Date().getFullYear()} NAGRIVOX. All rights reserved.</small></div>
  </div></footer>;
}
