export default function Header() {
  return <>
    <div className="topbar"><span>INDEPENDENT • RESPONSIBLE • PUBLIC INTEREST</span><span>Digital News &amp; Public Affairs</span></div>
    <header className="masthead">
      <div className="mast">
        <a href="/" aria-label="NAGRIVOX home"><div className="logo">NAGRI<span>VOX</span></div><div className="tagline">Ideas That Matter. Voices That Count.</div></a>
        <div className="right"><a className="btn" href="/?lang=hi">हिन्दी</a><a className="btn primary" href="/about">About NAGRIVOX</a></div>
      </div>
      <nav className="nav">
        <a href="/">Home</a><a href="/category/politics">Politics</a><a href="/category/law">Law &amp; Constitution</a><a href="/category/society">Society</a><a href="/category/democracy">Democracy</a><a href="/category/opinion">Opinion</a>
      </nav>
    </header>
  </>;
}
