import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { createClient } from "@/lib/supabase/server";
import type { Article } from "@/lib/types";

export const revalidate = 60;

export default async function Home({ searchParams }: { searchParams: Promise<{lang?:string}> }) {
  const params = await searchParams;
  const hi = params.lang === "hi";
  const supabase = await createClient();
  const { data } = await supabase.from("articles").select("*").eq("status","published").order("published_at",{ascending:false}).limit(12);
  const articles = (data || []) as Article[];
  const featured = articles[0];
  return <>
    <Header/>
    <main className="shell">
      <div className="ticker">{hi ? "जागरूक बहस, विश्वसनीय पत्रकारिता और विविध दृष्टिकोणों का मंच।" : "A platform for informed debate, credible reporting and diverse perspectives."}</div>
      {featured ? <section className="hero">
        <a className="hero-main" href={`/article/${featured.slug}`}>
          <div className="eyebrow">{featured.category} • NAGRIVOX</div>
          <h1>{hi && featured.title_hi ? featured.title_hi : featured.title_en}</h1>
          <p>{hi && featured.excerpt_hi ? featured.excerpt_hi : featured.excerpt_en}</p>
        </a>
        <div className="side">
          <div className="sidebox"><div className="small">OUR MISSION</div><h3>{hi ? "विचारों में स्वतंत्र। अभिव्यक्ति में जिम्मेदार।" : "Independent in thought. Responsible in expression."}</h3><div className="small">NAGRIVOX</div></div>
          <div className="sidebox"><div className="small">OUR FOCUS</div><h3>{hi ? "राजनीति • कानून • समाज • लोकतंत्र" : "Politics • Law • Society • Democracy"}</h3><div className="small">PUBLIC AFFAIRS</div></div>
        </div>
      </section> : <section className="hero"><div className="hero-main"><div className="eyebrow">NAGRIVOX • PUBLIC AFFAIRS</div><h1>{hi ? "महत्त्वपूर्ण मुद्दों को समझिए।" : "Understand the issues shaping our world."}</h1><p>{hi ? "लोकतंत्र, शासन, कानून और समाज पर खबरें और विचार।" : "News, context and thoughtful perspectives on democracy, governance, law and society."}</p></div><div className="side"><div className="sidebox"><div className="small">OUR MISSION</div><h3>Independent in thought. Responsible in expression.</h3></div><div className="sidebox"><div className="small">OUR FOCUS</div><h3>Politics • Law • Society • Democracy</h3></div></div></section>}
      <div className="section-title"><h2>{hi ? "ताज़ा खबरें" : "Latest Stories"}</h2><span className="small">{articles.length} {hi ? "प्रकाशित लेख" : "published stories"}</span></div>
      {articles.length ? <div className="grid">{articles.map(a=><article className="card" key={a.id}>
        {a.cover_image ? <div className="cover" style={{backgroundImage:`url("${a.cover_image}")`}}/> : <div className="cover"/>}
        <div className="cardbody"><div className="category">{a.category}</div><h3><a href={`/article/${a.slug}`}>{hi && a.title_hi ? a.title_hi : a.title_en}</a></h3><p>{hi && a.excerpt_hi ? a.excerpt_hi : a.excerpt_en}</p><a className="link small" href={`/article/${a.slug}`}>{hi ? "आगे पढ़ें →" : "READ MORE →"}</a></div>
      </article>)}</div> : <div className="panel empty">No published stories yet. The newsroom is getting ready for its first report.</div>}
      <section className="about"><div><div className="eyebrow">ABOUT NAGRIVOX</div><h2 style={{fontFamily:"Playfair Display,Georgia,serif"}}>{hi ? "विचारों, सवालों और सार्वजनिक संवाद का मंच।" : "A space for ideas, questions and public conversation."}</h2><p>{hi ? "हम राजनीति, कानून, समाज, लोकतंत्र और जनहित के विषयों को समझने योग्य और तथ्य-आधारित तरीके से प्रस्तुत करने का प्रयास करते हैं।" : "NAGRIVOX explores politics, law, society, democracy and public affairs with a commitment to accuracy, fairness and respectful public discourse."}</p></div><div><b>OUR PRINCIPLES</b><p>• Accuracy before speed<br/>• Independence and fairness<br/>• Respectful public discourse<br/>• Clear distinction between news and opinion</p></div></section>
    </main><Footer/>
  </>;
}
