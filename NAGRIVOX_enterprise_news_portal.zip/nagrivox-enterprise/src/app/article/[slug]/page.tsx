import { notFound } from "next/navigation";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { createClient } from "@/lib/supabase/server";

export default async function ArticlePage({ params }: { params: Promise<{slug:string}> }) {
  const { slug } = await params;
  const supabase = await createClient();
  const { data } = await supabase.from("articles").select("*").eq("slug",slug).eq("status","published").maybeSingle();
  if (!data) notFound();
  return <><Header/><main className="article-page">
    <div className="category">{data.category}</div><h1>{data.title_en}</h1>
    <p className="muted">{data.published_at ? new Date(data.published_at).toLocaleDateString("en-IN",{dateStyle:"long"}) : ""}</p>
    {data.cover_image && <img className="article-image" src={data.cover_image} alt="Article cover"/>}
    {data.excerpt_en && <p style={{fontSize:19,fontWeight:600}}>{data.excerpt_en}</p>}
    <div className="article-body">{data.body_en}</div>
    {data.title_hi && <><hr style={{margin:"30px 0",border:0,borderTop:"1px solid #e4e7ed"}}/><div className="category">हिंदी संस्करण</div><h2 style={{fontFamily:"Playfair Display,Georgia,serif"}}>{data.title_hi}</h2><p>{data.excerpt_hi}</p><div className="article-body">{data.body_hi}</div></>}
  </main><Footer/></>;
}
