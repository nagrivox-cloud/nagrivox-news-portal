import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "NAGRIVOX | Ideas That Matter. Voices That Count.",
  description: "Independent news and public affairs covering politics, law, society and democracy."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
