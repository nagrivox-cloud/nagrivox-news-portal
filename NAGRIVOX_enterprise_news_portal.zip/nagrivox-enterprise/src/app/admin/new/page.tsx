"use client";
import { useState } from "react"; import { createClient } from "@/lib/supabase/client"; import { useRouter } from "next/navigation";
export default function NewArticle(){
 const router=useRouter(); const [busy,setBusy]=useState(false); const [error,setError]=useState("");
 const [form,setForm]=useState({title_en:"",title_hi:"",slug:"",category:"Politics",excerpt_en:"",excerpt_hi:"",body_en:"",body_hi:"",cover_image:"",status:"draft"});
 function set(k:string,v:string){setForm(p=>({...p,[k]:v}));}
 function slugify(s:string){return s.toLowerCase().trim().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");}
 async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setError("");const supabase=createClient();const {data:{user}}=await supabase.auth.getUser();if(!user){setError("Please sign in again.");setBusy(false);return;}
 const slug=form.slug||slugify(form.title_en);const {error}=await supabase.from("articles").insert({...form,slug,author_id:user.id,published_at:form.status==="published"?new Date().toISOString():null});
 setBusy(false);if(error){setError(error.message);return;}router.push("/admin");router.refresh();}
 return <div className="panel"><div className="category">EDITORIAL DESK</div><h1 style={{fontFamily:"Playfair Display,Georgia,serif"}}>Create article</h1><p className="muted">Prepare a bilingual story. Reporters can save drafts or submit for review.</p>
 <form className="form" onSubmit={submit}>
 <div className="field"><label>English headline *</label><input required value={form.title_en} onChange={e=>set("title_en",e.target.value)}/></div>
 <div className="field"><label>Hindi headline</label><input value={form.title_hi} onChange={e=>set("title_hi",e.target.value)}/></div>
 <div className="field"><label>URL slug (optional)</label><input placeholder="auto-generated-from-headline" value={form.slug} onChange={e=>set("slug",e.target.value)}/></div>
 <div className="field"><label>Category</label><select value={form.category} onChange={e=>set("category",e.target.value)}>{["Politics","Law & Constitution","Society","Democracy","Opinion","Explainer","Local News"].map(x=><option key={x}>{x}</option>)}</select></div>
 <div className="field"><label>English summary</label><textarea value={form.excerpt_en} onChange={e=>set("excerpt_en",e.target.value)}/></div>
 <div className="field"><label>Hindi summary</label><textarea value={form.excerpt_hi} onChange={e=>set("excerpt_hi",e.target.value)}/></div>
 <div className="field"><label>English article *</label><textarea required value={form.body_en} onChange={e=>set("body_en",e.target.value)} style={{minHeight:220}}/></div>
 <div className="field"><label>Hindi article</label><textarea value={form.body_hi} onChange={e=>set("body_hi",e.target.value)} style={{minHeight:180}}/></div>
 <div className="field"><label>Cover image URL</label><input type="url" placeholder="https://..." value={form.cover_image} onChange={e=>set("cover_image",e.target.value)}/></div>
 <div className="field"><label>Workflow status</label><select value={form.status} onChange={e=>set("status",e.target.value)}><option value="draft">Save draft</option><option value="in_review">Submit for review</option></select><small className="muted">Publishing is reserved for editors and owners from the review workflow.</small></div>
 {error&&<div className="notice error">{error}</div>}<button className="btn primary" disabled={busy}>{busy?"Saving…":"Save article"}</button>
 </form></div>;
}
