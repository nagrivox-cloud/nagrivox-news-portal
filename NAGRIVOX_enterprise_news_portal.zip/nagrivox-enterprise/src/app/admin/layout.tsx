import Link from "next/link"; import { redirect } from "next/navigation"; import { createClient } from "@/lib/supabase/server";
export default async function AdminLayout({children}:{children:React.ReactNode}){
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user) redirect("/login");
 const {data:profile}=await supabase.from("profiles").select("display_name,role").eq("id",user.id).single();
 if(!profile) redirect("/login");
 return <><div className="topbar"><span>NAGRIVOX NEWSROOM</span><span>{profile.display_name} · {profile.role}</span></div><div className="shell" style={{paddingTop:25}}><div className="dashboard-grid"><aside className="panel sidebar"><b>EDITORIAL DESK</b><Link href="/admin">Dashboard</Link><Link href="/admin/new">Create article</Link><Link href="/">View public site ↗</Link><form action="/auth/signout" method="post"><button className="btn" style={{width:"100%"}}>Sign out</button></form></aside><section>{children}</section></div></div></>;
}
