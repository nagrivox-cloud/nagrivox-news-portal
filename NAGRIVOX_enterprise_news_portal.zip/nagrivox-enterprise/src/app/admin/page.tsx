import Link from "next/link"; import { createClient } from "@/lib/supabase/server";
export default async function AdminHome(){
 const supabase=await createClient(); const {data:profile}=await supabase.from("profiles").select("role").single();
 const {data:articles}=await supabase.from("articles").select("id,title_en,category,status,updated_at").order("updated_at",{ascending:false}).limit(50);
 const canReview=profile?.role==="owner"||profile?.role==="editor";
 return <div className="panel"><div className="right" style={{justifyContent:"space-between"}}><div><div className="category">NEWSROOM</div><h1 style={{fontFamily:"Playfair Display,Georgia,serif",margin:"5px 0"}}>Editorial dashboard</h1><p className="muted">Manage drafts, submissions and published stories.</p></div><Link className="btn primary" href="/admin/new">+ New article</Link></div>
 <div className="section-title"><h2>Articles</h2><span className="small">{articles?.length||0} recent items</span></div>
 {!articles?.length?<div className="empty">No articles yet. Create your first draft.</div>:<div className="tablewrap"><table className="table"><thead><tr><th>Headline</th><th>Category</th><th>Status</th><th>Updated</th><th></th></tr></thead><tbody>{articles.map(a=><tr key={a.id}><td><b>{a.title_en}</b></td><td>{a.category}</td><td><span className="badge">{a.status.replace("_"," ")}</span></td><td>{new Date(a.updated_at).toLocaleDateString("en-IN")}</td><td>{canReview||a.status!=="published"?<Link className="link" href={`/admin/edit/${a.id}`}>Edit</Link>:null}</td></tr>)}</tbody></table></div>}
 </div>;
}
