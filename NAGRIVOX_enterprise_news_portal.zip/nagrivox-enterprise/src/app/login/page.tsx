"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import Header from "@/components/Header";

export default function Login(){
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [error,setError]=useState(""); const [busy,setBusy]=useState(false);
  async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setError("");const supabase=createClient();const {error}=await supabase.auth.signInWithPassword({email,password});setBusy(false);if(error){setError(error.message);return;}window.location.href="/admin";}
  return <><Header/><main className="article-page"><div className="category">NEWSROOM ACCESS</div><h1>Team sign in</h1><p className="muted">Authorized NAGRIVOX newsroom members only.</p><form className="form" onSubmit={submit}><div className="field"><label>Email</label><input type="email" required value={email} onChange={e=>setEmail(e.target.value)} autoComplete="username"/></div><div className="field"><label>Password</label><input type="password" required value={password} onChange={e=>setPassword(e.target.value)} autoComplete="current-password"/></div>{error&&<div className="notice error">{error}</div>}<button className="btn primary" disabled={busy}>{busy?"Signing in…":"Sign in"}</button></form></main></>;
}
